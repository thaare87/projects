### xPDF50

Given a URL of Harvard's CS50 web page containing a project, a problem, a lab or lecture notes xPDF50 outputs a clean PDF file of that project, problem, lab or notes.

> Installation

     $ pip install xPDF50

Please note that following modules are 'required' for xPDF50 to work. 
* Pillow
* requests
* xhtml2pdf


> Usage

     $ xPDF50 url

Make sure to provide a URL of a cs50.harvard.edu page containing a project, a problem, a lab or lecture notes.

*** Important: Download the pdf file to the PC to view it 

     



